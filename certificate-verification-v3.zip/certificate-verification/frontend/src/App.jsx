import { useState } from "react";
import AuthPage from "./pages/AuthPage.jsx";
import StudentPage from "./pages/StudentPage.jsx";
import AdminPage from "./pages/AdminPage.jsx";
import VerifyPage from "./pages/VerifyPage.jsx";
import Guilloche from "./components/Guilloche.jsx";
import { BRAND } from "./config";

function savedUser() {
  try { return JSON.parse(localStorage.getItem("user")); } catch { return null; }
}

export default function App() {
  const [user, setUser] = useState(savedUser);
  const [publicVerify, setPublicVerify] = useState(new URLSearchParams(window.location.search).has("hash"));

  function onAuth({ token, user }) {
    localStorage.setItem("token", token);
    localStorage.setItem("user", JSON.stringify(user));
    setUser(user);
  }

  function signOut() {
    localStorage.clear();
    setUser(null);
  }

  return (
    <div className="shell">
      <header className="masthead no-print">
        <div className="brand">
          <Guilloche className="brand-mark" simple />
          <div>
            <h1>{BRAND.name}</h1>
            <p className="muted">{BRAND.institution}</p>
          </div>
        </div>
        <div className="bar-actions">
          {user && <span className="muted">{user.name}</span>}
          {publicVerify
            ? <button className="link" onClick={() => setPublicVerify(false)}>Back</button>
            : <button className="link" onClick={() => setPublicVerify(true)}>Verify a certificate</button>}
          {user && <button className="link" onClick={signOut}>Sign out</button>}
        </div>
      </header>
      <main>
        {publicVerify ? <VerifyPage />
          : !user ? <AuthPage onAuth={onAuth} onVerify={() => setPublicVerify(true)} />
          : user.role === "admin" ? <AdminPage /> : <StudentPage />}
      </main>
    </div>
  );
}
