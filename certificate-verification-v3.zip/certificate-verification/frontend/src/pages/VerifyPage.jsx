import { useEffect, useState } from "react";
import { getReadContract, friendlyError } from "../utils/contract";
import { hashFile, isValidHash } from "../utils/hash";
import DropZone from "../components/DropZone";
import Guilloche from "../components/Guilloche";
import { BRAND } from "../config";

const TITLES = { valid: "Genuine certificate", revoked: "Certificate revoked", unknown: "No record found" };
const MARKS = { valid: "\u2713", revoked: "!", unknown: "?" };

export default function VerifyPage() {
  const [file, setFile] = useState(null);
  const [hashInput, setHashInput] = useState(new URLSearchParams(window.location.search).get("hash") || "");
  const [state, setState] = useState({ status: "idle" });

  async function verify(hash) {
    setState({ status: "loading" });
    try {
      const res = await getReadContract().verifyCertificate(hash);
      const cert = res.cert;
      if (!cert.exists) return setState({ status: "unknown", hash });
      setState({
        status: res.valid ? "valid" : "revoked",
        hash,
        cert: {
          studentName: cert.studentName,
          course: cert.course,
          issuer: cert.issuer,
          issuedAt: new Date(Number(cert.issuedAt) * 1000).toLocaleDateString(undefined, { dateStyle: "long" }),
        },
      });
    } catch (err) {
      setState({ status: "error", message: friendlyError(err) });
    }
  }

  async function onSubmit(e) {
    e.preventDefault();
    try {
      const hash = file ? await hashFile(file) : hashInput.trim();
      if (!isValidHash(hash)) {
        return setState({ status: "error", message: "Choose a file, or paste a hash that starts with 0x and has 64 more characters." });
      }
      await verify(hash);
    } catch (err) {
      setState({ status: "error", message: friendlyError(err) });
    }
  }

  useEffect(() => {
    if (isValidHash(hashInput)) verify(hashInput);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const result = ["valid", "revoked", "unknown"].includes(state.status);

  return (
    <div className="stack narrow-page">
      <section className="panel no-print">
        <h2>Verify a certificate</h2>
        <form onSubmit={onSubmit}>
          <DropZone file={file} onFile={setFile} label="Drop the certificate file here, or click to browse" />
          <p className="or">or</p>
          <label>Certificate hash
            <input type="text" placeholder="0x…" value={hashInput} onChange={(e) => setHashInput(e.target.value)} />
          </label>
          <button className="primary" disabled={state.status === "loading"}>
            {state.status === "loading" && <span className="spinner" />}
            {state.status === "loading" ? "Checking" : "Verify certificate"}
          </button>
        </form>
        {state.status === "error" && <p className="notice bad" role="alert">{state.message}</p>}
      </section>

      {result && (
        <>
          <section className={`result ${state.status} printable`} role="status">
            <Guilloche className="result-art" />
            <div className="seal" aria-hidden="true">{MARKS[state.status]}</div>
            <div className="result-body">
              <h2>{TITLES[state.status]}</h2>
              {state.cert ? (
                <dl>
                  <dt>Awarded to</dt><dd>{state.cert.studentName}</dd>
                  <dt>Course</dt><dd>{state.cert.course}</dd>
                  <dt>Issued on</dt><dd>{state.cert.issuedAt}</dd>
                  <dt>Issued by</dt><dd className="mono">{state.cert.issuer}</dd>
                  <dt>Hash</dt><dd className="mono">{state.hash}</dd>
                </dl>
              ) : (
                <p>This file was never issued here, or it was changed after it was issued.</p>
              )}
              <p className="small">Checked against the {BRAND.institution} blockchain record on {new Date().toLocaleDateString(undefined, { dateStyle: "long" })}.</p>
            </div>
          </section>
          <div className="no-print"><button className="secondary" onClick={() => window.print()}>Print or save as PDF</button></div>
        </>
      )}
    </div>
  );
}
