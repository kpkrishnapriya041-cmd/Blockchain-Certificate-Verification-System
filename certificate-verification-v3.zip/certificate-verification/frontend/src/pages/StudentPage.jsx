import { useEffect, useState } from "react";
import { api } from "../api";
import StatusPill from "../components/StatusPill";
import DropZone from "../components/DropZone";
import FilePreview from "../components/FilePreview";
import ShareBlock from "../components/ShareBlock";
import { useToast } from "../components/Toast";

const fmt = (d) => new Date(d).toLocaleDateString(undefined, { dateStyle: "medium" });

export default function StudentPage() {
  const toast = useToast();
  const [course, setCourse] = useState("");
  const [file, setFile] = useState(null);
  const [items, setItems] = useState(null);
  const [busy, setBusy] = useState(false);

  const refresh = () => api("/api/certificates/mine").then(setItems).catch((e) => toast(e.message, "bad"));
  useEffect(() => { refresh(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  async function onSubmit(e) {
    e.preventDefault();
    if (!file) return toast("Choose your certificate file first.", "bad");
    setBusy(true);
    try {
      const form = new FormData();
      form.append("course", course);
      form.append("file", file);
      await api("/api/certificates", { method: "POST", form });
      setCourse("");
      setFile(null);
      toast("Uploaded. Your college will review it soon.");
      await refresh();
    } catch (err) {
      toast(err.message, "bad");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="stack">
      <section className="panel">
        <h2>Upload a certificate</h2>
        <form onSubmit={onSubmit}>
          <label>Course or qualification
            <input type="text" required value={course} onChange={(e) => setCourse(e.target.value)} />
          </label>
          <DropZone file={file} onFile={setFile} />
          <button className="primary" disabled={busy}>
            {busy && <span className="spinner" />}
            {busy ? "Uploading" : "Upload for verification"}
          </button>
        </form>
      </section>

      <section className="panel">
        <h2>Your certificates</h2>
        {items === null && <p className="muted"><span className="spinner" /> Loading</p>}
        {items && items.length === 0 && <p className="muted">Nothing uploaded yet. Your certificates and their status will appear here.</p>}
        {items && items.map((c) => (
          <article className="item" key={c.id}>
            <FilePreview id={c.id} name={c.originalName} />
            <div className="item-main">
              <div className="item-head"><strong>{c.course}</strong><StatusPill status={c.status} /></div>
              <p className="muted">{c.originalName}, uploaded {fmt(c.createdAt)}</p>
              {c.status === "pending" && <p className="small">Your college hasn't reviewed this yet.</p>}
              {c.status === "verified" && <ShareBlock cert={c} />}
              {c.status === "rejected" && <p className="notice bad">Reason: {c.note}</p>}
              {c.status === "revoked" && <p className="notice bad">This certificate was revoked. Reason: {c.note}</p>}
            </div>
          </article>
        ))}
      </section>
    </div>
  );
}
