import { useEffect, useMemo, useState } from "react";
import { api } from "../api";
import StatusPill from "../components/StatusPill";
import FilePreview from "../components/FilePreview";
import { useToast } from "../components/Toast";

const STATS = [
  ["all", "All uploads"],
  ["pending", "Waiting for review"],
  ["verified", "Recorded on blockchain"],
  ["rejected", "Rejected"],
  ["revoked", "Revoked"],
];

export default function AdminPage() {
  const toast = useToast();
  const [items, setItems] = useState(null);
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");
  const [busyId, setBusyId] = useState(null);

  const refresh = () => api("/api/certificates").then(setItems).catch((e) => toast(e.message, "bad"));
  useEffect(() => { refresh(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const counts = useMemo(() => {
    const c = { all: items ? items.length : 0, pending: 0, verified: 0, rejected: 0, revoked: 0 };
    (items || []).forEach((i) => { c[i.status] += 1; });
    return c;
  }, [items]);

  const shown = useMemo(() => {
    const q = query.trim().toLowerCase();
    return (items || []).filter((i) =>
      (filter === "all" || i.status === filter) &&
      (!q || [i.studentName, i.course, i.hash, i.originalName].some((v) => v.toLowerCase().includes(q)))
    );
  }, [items, filter, query]);

  async function openFile(id) {
    try {
      const blob = await api(`/api/certificates/${id}/file`);
      window.open(URL.createObjectURL(blob), "_blank");
    } catch (err) {
      toast(err.message, "bad");
    }
  }

  async function act(id, action, body, doneMessage) {
    setBusyId(id);
    try {
      await api(`/api/certificates/${id}/${action}`, { method: "POST", body });
      toast(doneMessage);
      await refresh();
    } catch (err) {
      toast(err.message, "bad");
    } finally {
      setBusyId(null);
    }
  }

  function ask(message, id, action, done) {
    const note = window.prompt(message);
    if (note !== null) act(id, action, { note }, done);
  }

  return (
    <div className="stack">
      <section className="stats" aria-label="Summary">
        {STATS.map(([key, label]) => (
          <button key={key} className={`stat${filter === key ? " active" : ""}`} onClick={() => setFilter(key)}>
            <span className="stat-num">{counts[key]}</span>
            <span className="stat-label">{label}</span>
          </button>
        ))}
      </section>

      <section className="panel">
        <div className="list-head">
          <h2>Certificates</h2>
          <input className="search" type="search" placeholder="Search by student, course or hash"
                 value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Search certificates" />
        </div>
        {items === null && <p className="muted"><span className="spinner" /> Loading</p>}
        {items && shown.length === 0 && (
          <p className="muted">{items.length === 0 ? "No certificates have been uploaded yet." : "No certificates match your search."}</p>
        )}
        {shown.map((c) => (
          <article className="item" key={c.id}>
            <FilePreview id={c.id} name={c.originalName} />
            <div className="item-main">
              <div className="item-head"><strong>{c.studentName}, {c.course}</strong><StatusPill status={c.status} /></div>
              <p className="muted">{c.originalName}, uploaded {new Date(c.createdAt).toLocaleString()}</p>
              <p className="mono">{c.hash}</p>
              {c.txHash && <p className="mono">Transaction: {c.txHash}</p>}
              {c.note && <p className="small">Reason: {c.note}</p>}
              <div className="actions">
                <button className="secondary" onClick={() => openFile(c.id)}>View file</button>
                {c.status === "pending" && (
                  <>
                    <button className="primary" disabled={busyId === c.id} onClick={() => act(c.id, "verify", undefined, "Recorded on the blockchain.")}>
                      {busyId === c.id && <span className="spinner" />}
                      {busyId === c.id ? "Recording" : "Verify and record on blockchain"}
                    </button>
                    <button className="secondary" disabled={busyId === c.id}
                            onClick={() => ask("Reason for rejecting (the student will see this):", c.id, "reject", "Certificate rejected.")}>Reject</button>
                  </>
                )}
                {c.status === "verified" && (
                  <button className="danger" disabled={busyId === c.id}
                          onClick={() => ask("Reason for revoking (the student will see this):", c.id, "revoke", "Certificate revoked on the blockchain.")}>
                    {busyId === c.id && <span className="spinner" />}
                    Revoke
                  </button>
                )}
              </div>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
}
