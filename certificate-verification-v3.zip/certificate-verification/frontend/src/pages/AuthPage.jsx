import { useState } from "react";
import { api } from "../api";
import Guilloche from "../components/Guilloche.jsx";

export default function AuthPage({ onAuth, onVerify }) {
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  async function onSubmit(e) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      onAuth(await api(`/api/auth/${mode}`, { method: "POST", body: form }));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="auth">
      <section className="hero">
        <Guilloche className="hero-art" animate />
        <div className="hero-text">
          <h2>Upload your certificate. Anyone can check that it's real.</h2>
          <p>Your college reviews each certificate, then records its digital fingerprint on a blockchain. Employers can confirm it in seconds, and nobody can quietly change it afterwards.</p>
        </div>
      </section>

      <section className="panel auth-form">
        <h2>{mode === "login" ? "Sign in" : "Create your account"}</h2>
        <form onSubmit={onSubmit}>
          {mode === "register" && (
            <label>Full name<input type="text" required autoComplete="name" value={form.name} onChange={set("name")} /></label>
          )}
          <label>Email<input type="text" required autoComplete="email" value={form.email} onChange={set("email")} /></label>
          <label>Password
            <input type="password" required autoComplete={mode === "login" ? "current-password" : "new-password"}
                   value={form.password} onChange={set("password")} />
          </label>
          <button className="primary" disabled={busy}>
            {busy && <span className="spinner" />}
            {busy ? "Please wait" : mode === "login" ? "Sign in" : "Create account"}
          </button>
        </form>
        {error && <p className="notice bad" role="alert">{error}</p>}
        <p className="switch">
          {mode === "login" ? "New student?" : "Already registered?"}{" "}
          <button className="link" onClick={() => { setMode(mode === "login" ? "register" : "login"); setError(""); }}>
            {mode === "login" ? "Create an account" : "Sign in"}
          </button>
        </p>
        <p className="switch">
          Checking someone else's certificate?{" "}
          <button className="link" onClick={onVerify}>Verify without signing in</button>
        </p>
      </section>
    </div>
  );
}
