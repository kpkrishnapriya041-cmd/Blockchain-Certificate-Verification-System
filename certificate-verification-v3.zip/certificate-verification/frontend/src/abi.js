// Human-readable ABI. Keep in sync with contracts-app/contracts/CertificateRegistry.sol
export const REGISTRY_ABI = [
  "function owner() view returns (address)",
  "function isIssuer(address) view returns (bool)",
  "function addIssuer(address issuer)",
  "function issueCertificate(bytes32 certHash, string studentName, string course)",
  "function revokeCertificate(bytes32 certHash)",
  "function verifyCertificate(bytes32 certHash) view returns (bool valid, tuple(address issuer, string studentName, string course, uint256 issuedAt, bool revoked, bool exists) cert)",
];
