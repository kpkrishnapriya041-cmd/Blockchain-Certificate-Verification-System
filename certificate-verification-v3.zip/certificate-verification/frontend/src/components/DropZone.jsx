import { useRef, useState } from "react";

export default function DropZone({ file, onFile, label = "Drop your certificate here, or click to browse" }) {
  const input = useRef(null);
  const [over, setOver] = useState(false);
  const take = (f) => { if (f) onFile(f); };

  return (
    <div
      className={`drop${over ? " over" : ""}${file ? " has" : ""}`}
      tabIndex={0}
      role="button"
      aria-label={label}
      onClick={() => input.current.click()}
      onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); input.current.click(); } }}
      onDragOver={(e) => { e.preventDefault(); setOver(true); }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => { e.preventDefault(); setOver(false); take(e.dataTransfer.files[0]); }}
    >
      <input ref={input} type="file" accept=".pdf,.png,.jpg,.jpeg" hidden onChange={(e) => take(e.target.files[0])} />
      {file ? (
        <>
          <strong>{file.name}</strong>
          <span>{Math.max(1, Math.round(file.size / 1024))} KB. Click to choose a different file.</span>
        </>
      ) : (
        <>
          <strong>{label}</strong>
          <span>PDF, PNG or JPG, up to 10 MB</span>
        </>
      )}
    </div>
  );
}
