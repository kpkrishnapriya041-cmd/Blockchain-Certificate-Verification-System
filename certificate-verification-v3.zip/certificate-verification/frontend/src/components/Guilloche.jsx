// Guilloche rosette: the fine line pattern printed on banknotes and certificates.
const LAYERS = [[100, 17, 17], [100, 17, 10], [100, 23, 12]];
const cache = {};

function makePath(R, r, d, steps) {
  const k = (R - r) / r;
  let out = "";
  for (let i = 0; i <= steps; i++) {
    const t = (i / steps) * 2 * Math.PI * r;
    const x = (R - r) * Math.cos(t) + d * Math.cos(k * t);
    const y = (R - r) * Math.sin(t) - d * Math.sin(k * t);
    out += (i ? "L" : "M") + x.toFixed(2) + " " + y.toFixed(2);
  }
  return out + "Z";
}

function paths(simple) {
  const key = simple ? "s" : "f";
  if (!cache[key]) cache[key] = (simple ? [LAYERS[0]] : LAYERS).map(([R, r, d]) => makePath(R, r, d, simple ? 900 : 1700));
  return cache[key];
}

export default function Guilloche({ className = "", simple = false, animate = false }) {
  return (
    <svg viewBox="-105 -105 210 210" className={className} aria-hidden="true" fill="none"
         stroke="currentColor" strokeWidth={simple ? 0.8 : 0.3}>
      <g className={animate ? "spin" : ""}>
        {paths(simple).map((d, i) => <path key={i} d={d} transform={`rotate(${i * 7})`} />)}
      </g>
    </svg>
  );
}
