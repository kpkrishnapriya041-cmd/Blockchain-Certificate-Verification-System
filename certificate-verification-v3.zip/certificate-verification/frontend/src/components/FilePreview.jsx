import { useEffect, useState } from "react";
import { api } from "../api";

export default function FilePreview({ id, name }) {
  const isImage = /\.(png|jpe?g)$/i.test(name);
  const [url, setUrl] = useState(null);

  useEffect(() => {
    if (!isImage) return undefined;
    let objectUrl;
    let cancelled = false;
    api(`/api/certificates/${id}/file`)
      .then((blob) => {
        if (cancelled) return;
        objectUrl = URL.createObjectURL(blob);
        setUrl(objectUrl);
      })
      .catch(() => {});
    return () => { cancelled = true; if (objectUrl) URL.revokeObjectURL(objectUrl); };
  }, [id, isImage]);

  return (
    <div className="thumb" aria-hidden="true">
      {isImage ? (url ? <img src={url} alt="" /> : <span className="spinner" />) : <span className="thumb-type">PDF</span>}
    </div>
  );
}
