import { QRCodeSVG } from "qrcode.react";
import { useToast } from "./Toast";

export default function ShareBlock({ cert }) {
  const toast = useToast();
  const link = `${window.location.origin}/?hash=${cert.hash}`;

  async function copy() {
    try {
      await navigator.clipboard.writeText(link);
      toast("Link copied.");
    } catch {
      toast("Couldn't copy. Select the link and copy it manually.", "bad");
    }
  }

  return (
    <div className="share">
      <div className="qr"><QRCodeSVG value={link} size={104} fgColor="#0E2233" bgColor="#ffffff" /></div>
      <div className="share-text">
        <p className="small">Anyone can scan the code or open this link to check the certificate.</p>
        <p className="mono">{link}</p>
        <button className="secondary" onClick={copy}>Copy link</button>
        <p className="small">Blockchain transaction</p>
        <p className="mono">{cert.txHash}</p>
      </div>
    </div>
  );
}
