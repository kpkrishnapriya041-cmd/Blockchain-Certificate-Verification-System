const LABELS = {
  pending: "Waiting for review",
  verified: "Recorded on blockchain",
  rejected: "Rejected",
  revoked: "Revoked",
};

export default function StatusPill({ status }) {
  return <span className={`pill ${status}`}>{LABELS[status] || status}</span>;
}
