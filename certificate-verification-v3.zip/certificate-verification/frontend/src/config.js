import addressFile from "./contracts/address.json";

export const CONTRACT_ADDRESS = import.meta.env.VITE_CONTRACT_ADDRESS || addressFile.address;
export const RPC_URL = import.meta.env.VITE_RPC_URL || "http://127.0.0.1:8545";
export const API_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";

// Change these two lines to your own names.
export const BRAND = { name: "Certificate Registry", institution: "Your College Name" };
