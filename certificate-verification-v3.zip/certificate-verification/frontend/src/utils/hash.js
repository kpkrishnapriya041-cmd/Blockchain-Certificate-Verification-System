// SHA-256 of a file, returned as a 0x-prefixed 32-byte hex string (fits bytes32).
export async function hashFile(file) {
  const buffer = await file.arrayBuffer();
  const digest = await crypto.subtle.digest("SHA-256", buffer);
  return (
    "0x" +
    [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("")
  );
}

export const isValidHash = (value) => /^0x[0-9a-fA-F]{64}$/.test(value);
