import { BrowserProvider, Contract, JsonRpcProvider } from "ethers";
import { CONTRACT_ADDRESS, RPC_URL } from "../config";
import { REGISTRY_ABI } from "../abi";

// Read-only: anyone can verify without a wallet.
export function getReadContract() {
  return new Contract(CONTRACT_ADDRESS, REGISTRY_ABI, new JsonRpcProvider(RPC_URL));
}

// Write access: needs MetaMask and an authorized issuer account.
export async function getWriteContract() {
  if (!window.ethereum) {
    throw new Error("MetaMask is not installed. Install it to issue certificates.");
  }
  const provider = new BrowserProvider(window.ethereum);
  await provider.send("eth_requestAccounts", []);
  const signer = await provider.getSigner();
  return new Contract(CONTRACT_ADDRESS, REGISTRY_ABI, signer);
}

export function friendlyError(err) {
  const text = err?.reason || err?.shortMessage || err?.message || "Something went wrong.";
  if (text.includes("Not authorized issuer")) return "This wallet is not an authorized issuer.";
  if (text.includes("Already issued")) return "This certificate was already issued.";
  if (text.includes("user rejected")) return "You cancelled the transaction in your wallet.";
  return text;
}
