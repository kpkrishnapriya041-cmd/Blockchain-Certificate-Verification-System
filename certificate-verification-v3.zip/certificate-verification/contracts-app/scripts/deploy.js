const fs = require("fs");
const path = require("path");
const hre = require("hardhat");

async function main() {
  const Registry = await hre.ethers.getContractFactory("CertificateRegistry");
  const registry = await Registry.deploy();
  await registry.waitForDeployment();
  const address = await registry.getAddress();
  console.log("CertificateRegistry deployed to:", address);

  // Hand the address to the frontend automatically.
  const out = path.join(__dirname, "../../frontend/src/contracts/address.json");
  fs.writeFileSync(out, JSON.stringify({ address }, null, 2));
  console.log("Address written to", out);
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
