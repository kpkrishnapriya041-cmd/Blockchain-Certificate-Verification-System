// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title CertificateRegistry
/// @notice Stores SHA-256 hashes of certificates so anyone can verify them.
///         The certificate file itself never goes on-chain.
contract CertificateRegistry {
    address public owner;

    struct Certificate {
        address issuer;
        string studentName;
        string course;
        uint256 issuedAt;
        bool revoked;
        bool exists;
    }

    mapping(bytes32 => Certificate) private certificates;
    mapping(address => bool) public isIssuer;

    event CertificateIssued(bytes32 indexed certHash, address indexed issuer);
    event CertificateRevoked(bytes32 indexed certHash);
    event IssuerAdded(address indexed issuer);

    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }

    modifier onlyIssuer() {
        require(isIssuer[msg.sender], "Not authorized issuer");
        _;
    }

    constructor() {
        owner = msg.sender;
        isIssuer[msg.sender] = true;
        emit IssuerAdded(msg.sender);
    }

    function addIssuer(address issuer) external onlyOwner {
        isIssuer[issuer] = true;
        emit IssuerAdded(issuer);
    }

    function issueCertificate(
        bytes32 certHash,
        string calldata studentName,
        string calldata course
    ) external onlyIssuer {
        require(!certificates[certHash].exists, "Already issued");
        certificates[certHash] = Certificate(
            msg.sender,
            studentName,
            course,
            block.timestamp,
            false,
            true
        );
        emit CertificateIssued(certHash, msg.sender);
    }

    function revokeCertificate(bytes32 certHash) external onlyIssuer {
        Certificate storage c = certificates[certHash];
        require(c.exists, "Not found");
        require(c.issuer == msg.sender, "Not original issuer");
        require(!c.revoked, "Already revoked");
        c.revoked = true;
        emit CertificateRevoked(certHash);
    }

    function verifyCertificate(bytes32 certHash)
        external
        view
        returns (bool valid, Certificate memory cert)
    {
        cert = certificates[certHash];
        valid = cert.exists && !cert.revoked;
    }
}
