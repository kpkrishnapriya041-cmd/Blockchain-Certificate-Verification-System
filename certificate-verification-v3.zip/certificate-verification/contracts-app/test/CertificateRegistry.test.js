const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("CertificateRegistry", function () {
  let registry, owner, other;
  const hash = ethers.keccak256(ethers.toUtf8Bytes("certificate-1"));

  beforeEach(async () => {
    [owner, other] = await ethers.getSigners();
    const Registry = await ethers.getContractFactory("CertificateRegistry");
    registry = await Registry.deploy();
    await registry.waitForDeployment();
  });

  it("issues a certificate and verifies it", async () => {
    await registry.issueCertificate(hash, "Asha Nair", "Blockchain Basics");
    const [valid, cert] = await registry.verifyCertificate(hash);
    expect(valid).to.equal(true);
    expect(cert.studentName).to.equal("Asha Nair");
    expect(cert.course).to.equal("Blockchain Basics");
    expect(cert.issuer).to.equal(owner.address);
  });

  it("rejects duplicate hashes", async () => {
    await registry.issueCertificate(hash, "A", "B");
    await expect(registry.issueCertificate(hash, "A", "B")).to.be.revertedWith("Already issued");
  });

  it("rejects issuing from a non-issuer", async () => {
    await expect(
      registry.connect(other).issueCertificate(hash, "A", "B")
    ).to.be.revertedWith("Not authorized issuer");
  });

  it("lets the owner authorize a new issuer", async () => {
    await registry.addIssuer(other.address);
    await registry.connect(other).issueCertificate(hash, "A", "B");
    const [valid] = await registry.verifyCertificate(hash);
    expect(valid).to.equal(true);
  });

  it("only the owner can add issuers", async () => {
    await expect(registry.connect(other).addIssuer(other.address)).to.be.revertedWith("Not owner");
  });

  it("revokes a certificate", async () => {
    await registry.issueCertificate(hash, "A", "B");
    await registry.revokeCertificate(hash);
    const [valid, cert] = await registry.verifyCertificate(hash);
    expect(valid).to.equal(false);
    expect(cert.revoked).to.equal(true);
  });

  it("only the original issuer can revoke", async () => {
    await registry.issueCertificate(hash, "A", "B");
    await registry.addIssuer(other.address);
    await expect(registry.connect(other).revokeCertificate(hash)).to.be.revertedWith("Not original issuer");
  });

  it("reports unknown hashes as invalid", async () => {
    const unknown = ethers.keccak256(ethers.toUtf8Bytes("nope"));
    const [valid, cert] = await registry.verifyCertificate(unknown);
    expect(valid).to.equal(false);
    expect(cert.exists).to.equal(false);
  });
});
