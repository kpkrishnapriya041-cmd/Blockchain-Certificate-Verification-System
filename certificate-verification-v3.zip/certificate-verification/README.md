# Certificate Verification System (Blockchain)

## How it works
1. **Student signs in** (or creates an account).
2. **Student uploads a certificate** (PDF, PNG or JPG).
3. The server fingerprints the file (SHA-256) and marks it *Waiting for review*.
4. **Admin (registrar) signs in**, views the file and clicks **Verify and record on blockchain**
   (or rejects it with a reason).
5. The hash is written to the smart contract. The student now sees *Recorded on blockchain*,
   the transaction ID, and a link anyone can use to verify the certificate.
6. **Anyone** can verify a certificate without signing in: upload the file or paste the hash.
   A file that was changed by even one byte will not match.

```
certificate-verification/
├── contracts-app/   Solidity contract, tests, deploy script (Hardhat)
├── backend/         Express API: accounts, uploads, admin review, blockchain writes
└── frontend/        React app: login, student page, admin page, public verify
```

## Run on Windows (use 4 terminals, run commands one at a time)

**Terminal 1: blockchain** (keep open)
```bat
cd contracts-app
npm install
npx hardhat node
```

**Terminal 2: deploy the contract**
```bat
cd contracts-app
npm run deploy:local
```

**Terminal 3: backend**
```bat
cd backend
npm install
copy .env.example .env
npm start
```

**Terminal 4: frontend**
```bat
cd frontend
npm install
npm run dev
```
Open http://localhost:5173

If you restart `hardhat node`, run `npm run deploy:local` again, then restart the backend.

## Accounts
- **Admin:** `admin@college.test` / `admin123` (change in `backend/.env`)
- **Students:** register on the sign-in page.

No MetaMask is needed. The backend signs blockchain transactions with the issuer key in `backend/.env`.

## Security notes
- The key in `.env.example` is a public Hardhat test key. For a real deployment use your own key and never commit `.env`.
- Change `JWT_SECRET` and the admin password before sharing the app.
- `backend/data/db.json` is a simple file database for a project demo; use PostgreSQL or MongoDB for production.
- Only the hash goes on-chain. The uploaded files stay on the server.

## Testnet deployment (optional)
Fill in `contracts-app/.env` (see `.env.example`), run `npm run deploy:sepolia`, then set
`RPC_URL` and `ISSUER_PRIVATE_KEY` in `backend/.env` and `VITE_RPC_URL` in `frontend/.env`.

## What's new in version 3 (design and features)
- Redesigned look with a guilloche (banknote-style) pattern, light and dark mode, and a phone-friendly layout.
- **QR code** and **Copy link** on every verified certificate.
- **Admin dashboard:** summary cards (click to filter), search, file thumbnails.
- **Revoke** button for recorded certificates (written to the blockchain).
- **Drag and drop** file upload, loading spinners and pop-up messages.
- Verification result looks like a certificate card and can be printed or saved as PDF.
- Set your college name in `frontend/src/config.js` (the `BRAND` line).

After unzipping, run `npm install` again in the `frontend` folder (a QR code library was added).
