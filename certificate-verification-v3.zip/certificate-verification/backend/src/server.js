require("dotenv").config();
const express = require("express");
const cors = require("cors");
const multer = require("multer");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const { getContract } = require("./chain");

const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
const DATA_DIR = path.join(__dirname, "../data");
const UPLOAD_DIR = path.join(__dirname, "../uploads");
const DB_FILE = path.join(DATA_DIR, "db.json");
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// --- tiny JSON "database" (fine for a project; use PostgreSQL/MongoDB in production)
const load = () =>
  fs.existsSync(DB_FILE) ? JSON.parse(fs.readFileSync(DB_FILE, "utf8")) : { users: [], certificates: [] };
const save = (db) => fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));

// Create the admin (registrar) account on first start.
(() => {
  const db = load();
  const email = (process.env.ADMIN_EMAIL || "admin@college.test").toLowerCase();
  if (!db.users.some((u) => u.email === email)) {
    db.users.push({
      id: crypto.randomUUID(),
      name: "Registrar",
      email,
      role: "admin",
      passwordHash: bcrypt.hashSync(process.env.ADMIN_PASSWORD || "admin123", 10),
    });
    save(db);
  }
})();

const app = express();
app.use(cors({ origin: process.env.CORS_ORIGIN || "http://localhost:5173" }));
app.use(express.json());

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) =>
    ["application/pdf", "image/png", "image/jpeg"].includes(file.mimetype)
      ? cb(null, true)
      : cb(new Error("Upload a PDF, PNG or JPG file.")),
});

const sign = (u) => jwt.sign({ id: u.id, role: u.role }, JWT_SECRET, { expiresIn: "8h" });
const publicUser = (u) => ({ name: u.name, email: u.email, role: u.role });
const publicCert = ({ storedName, ...rest }) => rest;

function auth(roles) {
  return (req, res, next) => {
    const token = (req.headers.authorization || "").replace("Bearer ", "");
    try {
      const payload = jwt.verify(token, JWT_SECRET);
      if (roles && !roles.includes(payload.role)) return res.status(403).json({ error: "You don't have access to this." });
      req.user = payload;
      next();
    } catch {
      res.status(401).json({ error: "Please sign in." });
    }
  };
}

// --- auth
app.post("/api/auth/register", (req, res) => {
  const name = String(req.body.name || "").trim();
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  if (!name || !/^\S+@\S+\.\S+$/.test(email) || password.length < 6) {
    return res.status(400).json({ error: "Enter your name, a valid email and a password of 6+ characters." });
  }
  const db = load();
  if (db.users.some((u) => u.email === email)) {
    return res.status(409).json({ error: "An account with this email already exists." });
  }
  const user = { id: crypto.randomUUID(), name, email, role: "student", passwordHash: bcrypt.hashSync(password, 10) };
  db.users.push(user);
  save(db);
  res.status(201).json({ token: sign(user), user: publicUser(user) });
});

app.post("/api/auth/login", (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const user = load().users.find((u) => u.email === email);
  if (!user || !bcrypt.compareSync(String(req.body.password || ""), user.passwordHash)) {
    return res.status(401).json({ error: "Email or password is incorrect." });
  }
  res.json({ token: sign(user), user: publicUser(user) });
});

// --- certificates
app.post("/api/certificates", auth(["student"]), upload.single("file"), (req, res) => {
  const course = String(req.body.course || "").trim();
  if (!req.file || !course) return res.status(400).json({ error: "Enter the course name and choose a file." });

  const hash = "0x" + crypto.createHash("sha256").update(req.file.buffer).digest("hex");
  const db = load();
  if (db.certificates.some((c) => c.hash === hash)) {
    return res.status(409).json({ error: "This file has already been uploaded." });
  }
  const user = db.users.find((u) => u.id === req.user.id);
  const id = crypto.randomUUID();
  const storedName = id + path.extname(req.file.originalname).toLowerCase();
  fs.writeFileSync(path.join(UPLOAD_DIR, storedName), req.file.buffer);

  const cert = {
    id, userId: user.id, studentName: user.name, course,
    originalName: req.file.originalname, storedName, hash,
    status: "pending", txHash: null, note: null, createdAt: new Date().toISOString(),
  };
  db.certificates.push(cert);
  save(db);
  res.status(201).json(publicCert(cert));
});

app.get("/api/certificates/mine", auth(["student"]), (req, res) => {
  const mine = load().certificates.filter((c) => c.userId === req.user.id);
  res.json(mine.reverse().map(publicCert));
});

app.get("/api/certificates", auth(["admin"]), (req, res) => {
  res.json(load().certificates.slice().reverse().map(publicCert));
});

app.get("/api/certificates/:id/file", auth(), (req, res) => {
  const cert = load().certificates.find((c) => c.id === req.params.id);
  if (!cert || (req.user.role !== "admin" && cert.userId !== req.user.id)) {
    return res.status(404).json({ error: "Certificate not found." });
  }
  res.sendFile(path.join(UPLOAD_DIR, cert.storedName));
});

// Admin approves: the hash is recorded on the blockchain.
app.post("/api/certificates/:id/verify", auth(["admin"]), async (req, res) => {
  const db = load();
  const cert = db.certificates.find((c) => c.id === req.params.id);
  if (!cert) return res.status(404).json({ error: "Certificate not found." });
  if (cert.status !== "pending") return res.status(400).json({ error: "This certificate was already reviewed." });
  try {
    const tx = await getContract().issueCertificate(cert.hash, cert.studentName, cert.course);
    await tx.wait();
    cert.status = "verified";
    cert.txHash = tx.hash;
    cert.reviewedAt = new Date().toISOString();
    save(db);
    res.json(publicCert(cert));
  } catch (err) {
    res.status(502).json({
      error: "Could not write to the blockchain. Check that the Hardhat node is running and the contract is deployed. " +
        (err.shortMessage || err.message),
    });
  }
});

app.post("/api/certificates/:id/reject", auth(["admin"]), (req, res) => {
  const db = load();
  const cert = db.certificates.find((c) => c.id === req.params.id);
  if (!cert) return res.status(404).json({ error: "Certificate not found." });
  if (cert.status !== "pending") return res.status(400).json({ error: "This certificate was already reviewed." });
  cert.status = "rejected";
  cert.note = String(req.body.note || "").trim() || "No reason given.";
  cert.reviewedAt = new Date().toISOString();
  save(db);
  res.json(publicCert(cert));
});

// Admin cancels an already recorded certificate (the blockchain keeps the history).
app.post("/api/certificates/:id/revoke", auth(["admin"]), async (req, res) => {
  const db = load();
  const cert = db.certificates.find((c) => c.id === req.params.id);
  if (!cert) return res.status(404).json({ error: "Certificate not found." });
  if (cert.status !== "verified") return res.status(400).json({ error: "Only recorded certificates can be revoked." });
  try {
    const tx = await getContract().revokeCertificate(cert.hash);
    await tx.wait();
    cert.status = "revoked";
    cert.note = String(req.body.note || "").trim() || "No reason given.";
    cert.revokeTxHash = tx.hash;
    cert.revokedAt = new Date().toISOString();
    save(db);
    res.json(publicCert(cert));
  } catch (err) {
    res.status(502).json({
      error: "Could not write to the blockchain. Check that the Hardhat node is running and the contract is deployed. " +
        (err.shortMessage || err.message),
    });
  }
});

app.get("/api/health", (req, res) => res.json({ ok: true }));
app.use((err, req, res, next) => res.status(400).json({ error: err.message }));

app.listen(PORT, () => console.log(`API running on http://localhost:${PORT}`));
