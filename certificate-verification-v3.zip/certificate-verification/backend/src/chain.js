const fs = require("fs");
const path = require("path");
const { ethers } = require("ethers");

const ABI = [
  "function issueCertificate(bytes32 certHash, string studentName, string course)",
  "function revokeCertificate(bytes32 certHash)",
];

function getContract() {
  const addressFile = path.join(__dirname, "../../frontend/src/contracts/address.json");
  const address = process.env.CONTRACT_ADDRESS || JSON.parse(fs.readFileSync(addressFile, "utf8")).address;
  const provider = new ethers.JsonRpcProvider(process.env.RPC_URL || "http://127.0.0.1:8545");
  const wallet = new ethers.Wallet(process.env.ISSUER_PRIVATE_KEY, provider);
  return new ethers.Contract(address, ABI, wallet);
}

module.exports = { getContract };
